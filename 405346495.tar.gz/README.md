# cs118_fall2020_project1

Find the project specification on the CCLE course page.
